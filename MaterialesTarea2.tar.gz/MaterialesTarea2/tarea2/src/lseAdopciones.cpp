#include "../include/lseAdopciones.h"

struct rep_lseadopciones {

};

TLSEAdopciones crearTLSEAdopcionesVacia(){
	return NULL;
}


bool esVaciaTLSEAdopciones(TLSEAdopciones lseAdopciones){
	return false;
}

void imprimirTLSEAdopciones(TLSEAdopciones lseAdopciones){

}

void liberarTLSEAdopciones(TLSEAdopciones &lseAdopciones){

}

void insertarTLSEAdopciones(TLSEAdopciones &lseAdopciones, TFecha fecha, TPersona persona, TPerro perro){

}

bool existeAdopcionTLSEAdopciones(TLSEAdopciones lseAdopciones, int ciPersona, int idPerro){
	return false;
}

void removerAdopcionTLSEAdopciones(TLSEAdopciones &lseAdopciones, int ciPersona, int idPerro){

}

