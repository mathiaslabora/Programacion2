#include "../include/fecha.h"

struct rep_fecha {

};

TFecha crearTFecha(nat dia, nat mes, nat anio) {
    return NULL;
}

void liberarTFecha(TFecha &fecha) {

}

void imprimirTFecha(TFecha fecha) {

}

TFecha copiarTFecha(TFecha fecha) {
    return NULL;
}

void aumentarTFecha(TFecha &fecha, nat dias) {

}

int compararTFechas(TFecha fecha1, TFecha fecha2) {
    return 0;
}
