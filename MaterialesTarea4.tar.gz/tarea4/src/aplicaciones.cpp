#include "../include/aplicaciones.h"

bool mismosElementos(TPila p, TColaPerros c) {
    return false;
}

TPila menoresQueElResto(TLDEPerros lista) {
    return NULL;
}
 
bool sumaPares(nat k, TConjuntoPerros c) {
    return false;
}