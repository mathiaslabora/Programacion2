#include "../include/tablaFichaVacunacion.h"

// Se debe implementar mediante una tabla de dispersión abierta (hash)

struct rep_tablaFichaVacunacion {
};

/* La función es O(cantEstimada) peor caso. */
TTablaFichaVacunacion crearTTablaFichaVacunacion(int cantEstimada){
    return NULL;
}

/* La función es O(n + max) peor caso, donde n es la cantidad actual de fichas en la tabla 
y max la cantidad esperada de fichas en la tabla. */
void liberarTTablaFichaVacunacion(TTablaFichaVacunacion &tabla){

}

// Para calcular la posición en la que se debe insertar la asociación en
// la tabla de dispersión abierta se debe utilizar la función de dispersión dada por 
// idPerro % tamanio (tamanio es la cantidad estimada de los elementos de la tabla).
// Por convención se deberá insertar la asociación al comienzo de la lista asociada a esa posición.
/* La función es O(1) peor caso. */
void insertarTTablaFichaVacunacion(TTablaFichaVacunacion &tabla, int idPerro, TAGFichaVacunacion ficha){

}

// Imprime cada ficha de vacunación de la tabla (idPerro, ficha), en orden creciente de 
// posiciones asociadas en la tabla, en líneas sucesivas (utilizando la función 'imprimirTAGFichaVacunacion')
// En caso de que haya más de una ficha en la misma posición, se deben imprimir por orden
// de ingreso a la tabla, desde la más reciente a la menos.
// La función es O(n + max) peor caso, donde n es la cantidad de fichas en la tabla 
// y max la cantidad esperada de fichas en la tabla.
void imprimirTTablaFichaVacunacion(TTablaFichaVacunacion tabla){
    
}

/* La función es O(1) promedio. */
bool perteneceTTablaFichaVacunacion(TTablaFichaVacunacion tabla, int idPerro){
    return false;
}

/* La función es O(1) promedio. */
TAGFichaVacunacion obtenerFichaTTablaFichaVacunacion(TTablaFichaVacunacion tabla, int idPerro){
    return NULL;
}

/* La función es O(1) promedio. */
void eliminarDeTTablaFichaVacunacion(TTablaFichaVacunacion &tabla, int idPerro){

}




