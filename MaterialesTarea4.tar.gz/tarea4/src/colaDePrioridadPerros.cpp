#include "../include/colaDePrioridadPerros.h"

// La cola de prioridad debe implementarse con un HEAP. 

// NOTA IMPORTANTE: Para evitar diferencias con las salidas esperadas de los tests: 
// * El filtrado ascendente debe parar cuando se encuentra un elemento igual o más prioritario que el elemento filtrado. 
// * El filtrado descendente debe parar cuando los hijos del elemento filtrado sean igual o menos prioritarios que el. 
// * Si se dan empates de prioridad entre los hijos durante el filtrado descendente y corresponde continuar filtrando, 
// se debe seguir el filtrado hacia la rama izquierda.

struct rep_colaDePrioridadPerros {

};

/* El tiempo de ejecución en el peor caso es O(N). */
TColaDePrioridadPerros crearTColaDePrioridadPerros(nat N) {
    return NULL;
}

/* El tiempo de ejecución en el peor caso es O(1). */
bool estaVaciaTColaDePrioridadPerros(TColaDePrioridadPerros cp) {
    return false;
}

/* El tiempo de ejecución en el peor caso es O(log N) siendp 'N' el parámetro pasado en crearCP. */
void insertarTColaDePrioridadPerros(TColaDePrioridadPerros &cp, TPerro perro) {

}

/* El tiempo de ejecución en el peor caso es O(1). */
bool estaTColaDePrioridadPerros(TColaDePrioridadPerros cp, int id) {
    return false;
}

/* El tiempo de ejecución en el peor caso es O(N), siendo 'N' el parámetro
pasado en crearCP. */
void liberarTColaDePrioridadPerros(TColaDePrioridadPerros &cp) {

}

/* El tiempo de ejecución en el peor caso es O(1). */
nat prioridadTColaDePrioridadPerros(TColaDePrioridadPerros cp, int id) {
    return 0;
}

/* El tiempo de ejecución en el peor caso es O(1). */
TPerro prioritarioTColaDePrioridadPerros(TColaDePrioridadPerros cp) {
    return NULL;
}

/* El tiempo de ejecución en el peor caso es O(log N), siendo 'N' el parámetro
pasado en crearCP. */
void eliminarPrioritarioTColaDePrioridadPerros(TColaDePrioridadPerros &cp) {

}

/* Se pide que el tiempo de ejecución en el peor caso sea O(n*log n), siendo 'n' la cantidad de
elementos de 'cp'. Sin embargo, existe una solución que lo hace en O(n). */
void invertirPrioridadTColaDePrioridadPerros(TColaDePrioridadPerros &cp) {

}
