#include "../include/refugio.h"

struct rep_refugio {
    
};

/* Ejecuta en O(1) peor caso. */
TRefugio crearTRefugio(int cantEstimada) {
    return NULL;
}

void liberarTRefugio(TRefugio &refugio) {
    
}

/* La función ejecuta en O(n) peor caso, donde n es la cantidad de vacunas en la ficha. */
void agregarVacunaTRefugio(TRefugio refugio, int codVacunaPadre, int codVacuna){

}

/* La función ejecuta en O(n) peor caso, donde n es la cantidad de vacunas en la ficha. */
void imprimirEsquemaVacunacionTRefugio(TRefugio refugio) {

}

/* La función ejecuta en O(n) peor caso, donde n es la cantidad de personas registradas en el refugio. */
// La persona parámetro no debe compartir memoria con el refugio.
void registrarPersonaTRefugio(TRefugio &refugio, TPersona persona) {

}

/* La función ejecuta en O(n) peor caso, donde n es la cantidad de personas registradas en el refugio. */
void imprimirPersonasTRefugio(TRefugio refugio) {

}

/* La función ejecuta en O(n) peor caso, donde n es la cantidad de perros en el refugio. */
// El perro parámetro no debe compartir memoria con el refugio. 
void ingresarPerroTRefugio(TRefugio &refugio, TPerro perro) {

}

/* La función ejecuta en O(n) peor caso, donde n es la cantidad de perros en la cola de paseos */
void imprimirColaPaseosTRefugio(TRefugio refugio) {

}

/* La función ejecuta en O(n) peor caso, donde n es la cantidad de perros en el refugio. */
void imprimirPerrosTRefugio(TRefugio refugio, bool cachorrosPrimero) {

}

/* La función ejecuta en O(cantidad) peor caso. */
void pasearPerrosTRefugio(TRefugio &refugio, nat cantidad) {

}

/* La función ejecuta en O(n + m + l) peor caso, donde n es la cantidad de perros
en el refugio, m la cantidad de personas en el refugio y l la cantidad de adopciones. */
// La fecha de la adopción agregada al refugio no comparte memoria con el parámetro. 
void adoptarPerroTRefugio(TRefugio &refugio, int idPerro, int ciPersona, TFecha fecha) {

}

/* Ejecuta en O(n) peor caso, donde n es la cantidad de adopciones del refugio. */
void imprimirAdopcionesTRefugio(TRefugio refugio) {

}

void vacunarPerroTRefugio(TRefugio refugio, int idPerro, int codVacunaPadre, int codVacuna){

}

void imprimirFichaVacunacionPerroTRefugio(TRefugio refugio, int idPerro){

}

TColaDePrioridadPerros obtenerPerrosSinVacunacionTRefugio(TRefugio &refugio){
    return NULL;
}

